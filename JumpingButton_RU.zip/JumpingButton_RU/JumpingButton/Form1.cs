﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JumpingButton
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        int score = 0;
        bool gameStarted = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!gameStarted)
            {
                timer1.Start();
                gameStarted = true;
            }
            button1.Left = rand.Next(0,200);
            button1.Top = rand.Next(0, 200);
            button1.BackColor = Color.Azure;
            score++;
            label1.Text = "Your score is: " + score.ToString();
            button1.Height = (int)(button1.Height * 0.9);
            button1.Width = (int)(button1.Width * 0.9);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button1.Left = rand.Next(0, 200);
            button1.Top = rand.Next(0, 200);
        }
    }
}
